import React from "react";
import '../css/home.css'
const Home=()=>{
    return(
        <>
      
        </>
    )
}
export default Home;