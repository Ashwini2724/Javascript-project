import React from "react";
import { Link } from "react-router-dom";
import "../css/nav.css";

const Nav = () => {
  return (
    <>
      <div>
        <ul className="nav">
          <li>
            <span
              className="text"
              style={{
                fontSize: "40px",
                color: "white",
                fontFamily: "cursive",
                fontWeight: "bold",
                textShadow: " 2px 3px red",
              }}
            >
              AshuClass
            </span>
          </li>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/about">About us</Link>
          </li>
          <li>
            <Link to="/services">Services</Link>
          </li>
          <li>
            <Link to="/portfolio">Portfolio</Link>
          </li>

          <li>
            <Link to="/contact">Contact</Link>
          </li>
          {/* <li>
            <Link to="/Login">Login</Link>
          </li> */}
           <li>
            <Link to="/logout">Logout</Link>
          </li>
          <li>
            <Link to="/register">Register</Link>
          </li>
        </ul>
      </div>
    </>
  );
};

export default Nav;
