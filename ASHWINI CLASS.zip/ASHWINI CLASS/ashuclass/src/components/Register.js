
import React, { useState } from "react";
import "../css/reg.css";
import { Link, useNavigate } from "react-router-dom";

const Register = () => {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();

  const collectdata = async () => {
    
    console.warn(name, phone, email, password);

    let result = await fetch('http://localhost:5000/register', {
      method: 'post',
      body: JSON.stringify({ name, phone, email, password }),
      headers: {
        "Content-Type": "application/json",
      },
    });

    result = await result.json();
    console.warn(result);

    if (result) {
      navigate("/");
    }
  };

  return (
    <>
      <div className="reg">
        <h1 className="head">Register here</h1>
        <div>
          <form method="POST">
            <label className="inputbox">Full Name:</label>
            <input
              type="text"
              className="inputbox"
              name="name"
              id="name"
              placeholder="Your Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
            <br />
            <br />
            <label className="inputbox">Phone no:</label>
            <input
              type="phone"
              className="inputbox"
              name="phone"
              id="phone"
              placeholder="Your phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
            <br />
            <br />
            <label className="inputbox">Email &nbsp;&nbsp;&nbsp;id:</label>
            <input
              type="email"
              className="inputbox"
              name="email"
              id="email"
              placeholder="Your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <br />
            <br />
            <label className="inputbox">password:</label>
            <input
              type="password"
              className="inputbox"
              name="password"
              id="password"
              placeholder="Your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <br />
            <br />
            <button className="btn" type="button" name="submit">
              Reset All
            </button>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <button
              className="btn"
              type="button"
              onClick={collectdata}
              name="submit"
            >
              Register
            </button>
            <div>
             
              <Link to="/login" className="linkto">
                Have already an account? Login here
              </Link>
            </div>
            <br />
          </form>
        </div>
      </div>
    </>
  );
};

export default Register;
